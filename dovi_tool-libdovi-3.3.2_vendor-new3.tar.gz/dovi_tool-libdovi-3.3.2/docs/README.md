Documentation related to `dovi_tool` usage

#### [Editor configuration](editor.md)
#### [Generator configuration](generator.md)
#### [Information about Dolby Vision profiles](profiles.md)
