//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Stitch.rc
//
#define IDC_MYICON                      2
#define IDD_STITCH_DIALOG               102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_STITCH                      107
#define IDI_SMALL                       108
#define IDC_STITCH                      109
#define IDR_MAINFRAME                   128
#define IDD_PROGRESS_DLG                131
#define IDC_PROGRESS_BAR                1000
#define IDC_BUTTON3                     1004
#define ID_FILE_OPEN                    32771
#define ID_OPTIONS_PRESENTER_DX11       32780
#define ID_OPTIONS_PRESENTER_DX9        32781
#define ID_OPTIONS_PRESENTER_OPENGL     32782
#define ID_PLAYBACK_PLAY                32785
#define ID_PLAYBACK_PAUSE               32786
#define ID_PLAYBACK_STEP                32788
#define ID_PLAYBACK_STOP                32789
#define ID_OPTIONS_LOOP                 32790
#define ID_OPTIONS_FORCE60FPS           32791
#define ID_FILE_CLEARFILELIST           32792
#define ID_OPTIONS_LOW_LATENCY          32798
#define ID_OPTIONS_EDITPROPERTIES       32799
#define ID_OPTIONS_DUMP_TEMPLATE        32800
#define ID_FILE_OPENPTGUIPROJECT        32801
#define ID_FILE_ZCAMLIVE                32802
#define ID_FILE_ZCAMLIVE_1080P          32803
#define ID_FILE_ZCAMLIVE_2K7            32804
#define ID_OPTIONS_RENDERER_DX11        32805
#define ID_OPTIONS_COMPUTE_FOR_DX11     32806
#define ID_OPTIONS_RENDERER_OPNECL      32807
#define ID_OPTIONS_RENDERER_OPENCL      32808
#define ID_OPTIONS_FULLSPEED            32809
#define ID_OPTIONS_SUBRESOURCE          32810
#define ID_SUBRESOURCE_INDEX0           32811
#define ID_SUBRESOURCE_INDEX1           32812
#define ID_SUBRESOURCE_INDEX2           32813
#define ID_SUBRESOURCE_INDEX3           32814
#define ID_SUBRESOURCE_INDEX4           32815
#define ID_SUBRESOURCE_INDEX5           32816
#define ID_FILE_ZCAMLIVE_2544P          32817
#define ID_FILE_RICOH                   32818
#define ID_FILE_RICOH_THETA_S           32819
#define ID_FILE_RICOHTHETASLIVE         32820
#define ID_FILE_RICOH_THETA_V           32821
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32822
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
