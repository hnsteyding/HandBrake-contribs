Differentiating between Dolby Vision profiles. 
##### Profile 4  
Possibly `vdr_bit_depth_minus8` > 4
##### Profile 5  
`vdr_rpu_profile = 0`  
`bl_video_full_range_flag = 0`
##### Profile 7  
`vdr_rpu_profile = 1`  
`el_spatial_resampling_filter_flag = 1`  
`disable_residual_flag = 0`
##### Profile 8  
`vdr_rpu_profile = 1`  
`el_spatial_resampling_filter_flag = 0`
