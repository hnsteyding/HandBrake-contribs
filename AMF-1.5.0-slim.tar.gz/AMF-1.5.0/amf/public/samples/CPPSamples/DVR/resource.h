//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DVR.rc
//
#define IDC_DVR                         101
#define IDI_DVR                         102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    104
#define IDD_NODEVICEBOX                 105
#define IDD_MAIN_DIALOG                 107
#define IDB_STOP                        1004
#define IDB_RECORD                      1005
#define IDE_MESSAGES                    1006
#define ID_DEVICE_START                 11000
#define ID_CAPTURE_SOURCE_START         12000
#define ID_CAPTURE_COMPONENT_START      13000
#define ID_PRE_ANALYSIS                 14000
#define IDM_EXIT                        40001
#define IDM_ABOUT                       40002
#define IDM_SAVEFILE                    40003
#define ID_CAPTURESOURCE_MULTI_MONITOR  40006

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
