---
name: General Question
about: Ask any general question about AMF
title: "[Question]: <Is X intended for Y?>"
labels: question
assignees: ''

---

Please avoid asking about future products or anything that is unreleased.
